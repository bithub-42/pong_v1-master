﻿using ConsolePong;
using System.Reflection.Metadata;
namespace Pong_Tests
{
    [TestClass]
    public class UserInputTest
    {
        [TestMethod]
        public void TestGetKeyState()
        {

        }
    }
}
