﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsolePong
{
    static class GameScreen
    {
        public static void GameEndScreen()
        {
            // Hier Design einfügen
        }

        public static void GameStartScreen()
        {
            // Hier Design einfügen
        }
    }
}
